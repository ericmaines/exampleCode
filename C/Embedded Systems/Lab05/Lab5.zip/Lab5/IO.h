#ifndef _IO_h
#define _IO_h
#include "stdint.h"

//Place prototypes for your pushbutton and LED functions here

void LEDs_off(void);
uint32_t pushbuttons(void);


#endif
