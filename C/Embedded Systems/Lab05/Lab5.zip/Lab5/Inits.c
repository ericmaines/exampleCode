#include "Inits.h"
#include "tm4c123gh6pm.h" // Hardware register definitions
#include "stdint.h"

// Initialize PD1 and PD0 as inputs
// Leave everything else unchanged
void PortD_Init(void){
	
}

// Initialize PE5, PE4, and PE3 as outputs
// Leave everything else unchanged
void PortE_Init(void){
	
}
