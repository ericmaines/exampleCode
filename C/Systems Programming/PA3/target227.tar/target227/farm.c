/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_285()
{
    return 2429004104U;
}

unsigned addval_443(unsigned x)
{
    return x + 3281162328U;
}

unsigned addval_419(unsigned x)
{
    return x + 2425510103U;
}

unsigned addval_158(unsigned x)
{
    return x + 3281031256U;
}

void setval_193(unsigned *p)
{
    *p = 3281031256U;
}

void setval_383(unsigned *p)
{
    *p = 2428995912U;
}

void setval_249(unsigned *p)
{
    *p = 2496104776U;
}

unsigned getval_134()
{
    return 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_375(unsigned *p)
{
    *p = 2464188744U;
}

void setval_420(unsigned *p)
{
    *p = 3286273352U;
}

unsigned addval_290(unsigned x)
{
    return x + 3769190619U;
}

unsigned addval_315(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_116()
{
    return 2462222704U;
}

void setval_463(unsigned *p)
{
    *p = 3676357249U;
}

unsigned getval_163()
{
    return 3374371273U;
}

void setval_199(unsigned *p)
{
    *p = 3221802649U;
}

unsigned getval_488()
{
    return 3264270729U;
}

unsigned addval_351(unsigned x)
{
    return x + 3767094468U;
}

void setval_337(unsigned *p)
{
    *p = 3263758522U;
}

void setval_124(unsigned *p)
{
    *p = 3381972617U;
}

unsigned addval_492(unsigned x)
{
    return x + 3286272328U;
}

void setval_485(unsigned *p)
{
    *p = 3536110217U;
}

unsigned addval_478(unsigned x)
{
    return x + 3674784393U;
}

unsigned addval_267(unsigned x)
{
    return x + 3281044097U;
}

unsigned addval_228(unsigned x)
{
    return x + 2496760215U;
}

void setval_483(unsigned *p)
{
    *p = 3525362185U;
}

unsigned addval_212(unsigned x)
{
    return x + 3351415102U;
}

unsigned addval_449(unsigned x)
{
    return x + 3526414729U;
}

void setval_112(unsigned *p)
{
    *p = 3677933209U;
}

unsigned addval_393(unsigned x)
{
    return x + 3285289346U;
}

unsigned getval_481()
{
    return 3352398100U;
}

unsigned addval_138(unsigned x)
{
    return x + 2430634312U;
}

void setval_314(unsigned *p)
{
    *p = 3523792585U;
}

void setval_109(unsigned *p)
{
    *p = 3526414729U;
}

void setval_352(unsigned *p)
{
    *p = 3676360329U;
}

unsigned getval_130()
{
    return 3376991881U;
}

unsigned getval_169()
{
    return 2425671305U;
}

void setval_397(unsigned *p)
{
    *p = 2497743176U;
}

unsigned getval_177()
{
    return 2425409161U;
}

unsigned addval_291(unsigned x)
{
    return x + 3586380169U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
