/* 
 * File: smartReverse.cpp
 * Purpose: provide the implementation of the smartReverse class
 *
 * Author: (your name)
 *
 */

#include <stack>
#include "smartReverse.h"

// default constructor
smartReverse::smartReverse()
{
}

// constructor: initialize str with ini_str passing as a parameter
smartReverse::smartReverse(string ini_str)
{
}

// return the current value of the private data member: str
string smartReverse::getString() const
{
}

// set the value of str to be the passed in parameter input_str
void smartReverse::setString(string input_str)
{
}

// return a reversed string from str
// using a loop to implement
// Note that str has not been changed
string smartReverse::rev() const
{
}

// return a reversed string from str
// using recursion to implement
// Note that str has not been changed
string smartReverse::rev_recursive() const
{
}

// return a reversed string from str
// using a stack to implement
// Note that str has not been changed
string smartReverse::rev_stack() const
{
}

