Files in this zip
    -Gradebook.h
        Defines the class the gradebook
    -Gradebook.cpp
        Defines the functions in the gradebook class
    -FinalGrade.h
        Defines the class FinalGrade
    -FinalGrade.cpp
        Defines the functions in the FinalGrade class
    -Project1.cpp
        Implements both classes into one program
    -Project1.exe
        An executable version of Project1.cpp

How to compile:
    You can compile this code with the g++ command in unix terminal.

        ex: $ g++ *.cpp -o Project1

    You don't need to compile the header files
